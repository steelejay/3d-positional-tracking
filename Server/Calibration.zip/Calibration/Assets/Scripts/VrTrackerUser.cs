﻿using UnityEngine;
using System.Collections;
using WebSocketSharp;
using UnityEngine.UI;
using SimpleJSON;

public class VrTrackerUser : MonoBehaviour {
	
	private WebSocket ws;
	private Vector3 position;
	private Vector3 previousPosition;
	public string GatewayIP = ""; // 85 // Set your gateway IP here
	//public string GatewayIP = "";
	public float scale = 0.01f;
	public float x_offset = 0.0f;
	public float y_offset = 0.0f;
	public float z_offset = 0.0f;
	public string WebsocketPort = "85";
	Text textComponent;
	public GameObject TextGameObject;
	public GameObject InputGameObject;
	Text inputTextComponent;
	private string textString;
	private bool jsonSend;
	public Transform CameraLocation;
	private Vector3 CameraPosition;
	private int intHeight;
	private int Mark1;
	private int Mark2;
	private int Mark3;
	private int Mark4;
	private int Mark5;



	void OnGUI(){
		jsonSend = false;
		//CONNECT
		if (GUI.Button (new Rect (790, 490, 250, 150), "Connect")) { 
			// Create and Open the websocket
			ws = new WebSocket("ws://"+ inputTextComponent.text);
			ws.OnOpen += OnOpenHandler;
			ws.OnMessage += OnMessageHandler;
			ws.OnClose += OnCloseHandler;

			ws.ConnectAsync();	
			jsonSend = false;
			Debug.Log ("ConnectButtonClick");
		}
		//DISCONNECT
		if (GUI.Button (new Rect (1050, 490, 250, 150), "Disconnect")) { //Correct
			jsonSend = false;
			ws.CloseAsync();
			Debug.Log ("ButtonClick");
		}

		//Debug.Log ("Button Function Run");
		//JSON SENDING
		var I = new JSONClass();

		if (GUI.Button (new Rect (270, 10, 250, 150), "Mark" + Mark1.ToString() +": 0,"+ intHeight.ToString() +",1")) { //Correct
			I["Command"] = "Coordinates";
			I["Mark"] = "Mark" + Mark1.ToString();
			I["Coordinates"]["X"] = "0";
			I["Coordinates"]["Y"] = intHeight.ToString();
			I["Coordinates"]["Z"] = "1";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (10, 170, 250, 150), "Mark" + Mark2.ToString() +": -1," + intHeight.ToString() + ",0")) { //Correct
			I["Command"] = "Coordinates";
			I["Mark"] = "Mark" + Mark2.ToString();
			I["Coordinates"]["X"] = "-1";
			I["Coordinates"]["Y"] = intHeight.ToString();
			I["Coordinates"]["Z"] = "0";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (270, 170, 250, 150), "Mark" + Mark3.ToString() +": 0,"+ intHeight.ToString() +",0")) { //Correct
			I["Command"] = "Coordinates";
			I["Mark"] = "Mark" + Mark3.ToString();
			I["Coordinates"]["X"] = "0";
			I["Coordinates"]["Y"] = intHeight.ToString();
			I["Coordinates"]["Z"] = "0";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}

		if (GUI.Button (new Rect (530, 170, 250, 150), "Mark" + Mark4.ToString() +": 1,"+ intHeight.ToString() +",0")) { //Correct
			I["Command"] = "Coordinates";
			I["Mark"] = "Mark" + Mark4.ToString();
			I["Coordinates"]["X"] = "1";
			I["Coordinates"]["Y"] = intHeight.ToString();
			I["Coordinates"]["Z"] = "0";
			jsonSend = true;

			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (270, 330, 250, 150), "Mark" + Mark5.ToString() +": 0,"+ intHeight.ToString() +",-1")) { //Correct
			I["Command"] = "Coordinates";
			I["Mark"] = "Mark" + Mark5.ToString();
			I["Coordinates"]["X"] = "0";
			I["Coordinates"]["Y"] = intHeight.ToString();
			I["Coordinates"]["Z"] = "-1";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (790, 170, 250, 150), "XYZ Output ON")) { //Correct
			I["Command"] = "XYZ_ON";
			jsonSend = true;

			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (790, 330, 250, 150), "XYZ Output OFF")) { //Correct
			I["Command"] = "XYZ_OFF";
			jsonSend = true;

			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (1050, 170, 250, 150), "Calibrate")) { //Correct
			I["Command"] = "Calibrate";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (1050, 330, 250, 150), "Load")) { //Correct
			I["Command"] = "Load";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (790, 10, 250, 150), "Height = " + intHeight.ToString ())) { //Correct
			if (intHeight == 1) {
				intHeight = 2;
				Mark1 = 6;
				Mark2 = 7;
				Mark3 = 8;
				Mark4 = 9;
				Mark5 = 10;
			} else {
				intHeight = 1;
				Mark1 = 1;
				Mark2 = 2;
				Mark3 = 3;
				Mark4 = 4;
				Mark5 = 5;
			}
			jsonSend = false;
			Debug.Log ("ButtonClick");
		}
		if (GUI.Button (new Rect (10, 490, 250, 150), "Reset")) { //Correct
			I["Command"] = "Reset";
			jsonSend = true;
			Debug.Log ("ButtonClick");
		}

		if (jsonSend == true) {
			ws.SendAsync (I.ToString (), OnSendComplete);
			jsonSend = false;
		}
	}

	void Awake(){
		textComponent = TextGameObject.GetComponent<Text>();
		textComponent.text ="Testing!";
		inputTextComponent = InputGameObject.GetComponent<Text>();
	}

	void Start () {
		
		// Retrieve the main camera

		intHeight = 1;
		Mark1 = 1;
		Mark2 = 2;
		Mark3 = 3;
		Mark4 = 4;
		Mark5 = 5;
	}
	
	private void OnOpenHandler(object sender, System.EventArgs e) {
		Debug.Log("Connected to Gateway!");
		textString = "Connected to Gateway!";

		//ws.SendAsync ("user-2", OnSendComplete);
	}
	
	private void OnMessageHandler(object sender, MessageEventArgs e) {
		// Split the position in XYZ
	//	string[] temp = e.Data.Split(":"[0]);
		
//		position.x = float.Parse(temp[0])+x_offset;
//		position.y = float.Parse(temp[2])+y_offset;
//		position.z = float.Parse(temp[1])+z_offset;
//		Debug.Log ("Position received : " + position);
		//Debug.Log(e.Data);
		textString = e.Data;
		var MessageArray = JSONNode.Parse(textString);
//		Debug.Log (MessageArray["MessageType"]);
		if (MessageArray["MessageType"].Value == "Coordinates"){
			Debug.Log ("IF ACCOMPLISHED");
			var CoordinatesArray = JSONNode.Parse(MessageArray ["Coordinates"].ToString()) ;
			Debug.Log ( CoordinatesArray );
			float Xf = CoordinatesArray ["X"].AsFloat; 
			float Yf  = CoordinatesArray ["Y"].AsFloat;
			float Zf = CoordinatesArray ["Z"].AsFloat;
			Debug.Log ("AFter floating");
			Debug.Log  (Xf);
			CameraPosition =  new Vector3 (Xf, Yf, Zf);

			}
		//textComponent.text = e.Data.ToString();
		// Here you can add some post treatment on the position (remove weird datas, add a Kalman filter, smoothen the curve...
			
		/*if (Mathf.Abs (previousPosition [0] - position [0]) > 20 || Mathf.Abs (previousPosition [1] - position [1]) > 20 || Mathf.Abs (previousPosition [2] - position [2]) > 20) {
			Debug.LogError ("Incoherent 3D position received");
		} else {
			position = previousPosition;
			Debug.Log (position);
		}*/
	}

	private void OnCloseHandler(object sender, CloseEventArgs e) {
		Debug.Log("Connection to Gateway closed for this reason: " + e.Reason);
		textString = "Connection to Gateway closed for this reason: " + e.Reason;
	}

	private void OnSendComplete(bool success) {

	}
	
	// Update is called once per frame
	void Update () {
	//	Debug.Log("Up");
		//Vector3 pos = new Vector3(position.x, position.y, position.z);
		textComponent.text =textString;

		CameraLocation.position = CameraPosition;

	}

	void OnApplicationQuit() {
		Debug.Log("Application ending after " + Time.time + " seconds");
		ws.Close();
	}

	void SendConfigCoordinates(string Coords){
		ws.SendAsync (Coords, OnSendComplete);
	}
	
}
